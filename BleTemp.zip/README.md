# TempLogger
reading data from BLE device and save to csv file
